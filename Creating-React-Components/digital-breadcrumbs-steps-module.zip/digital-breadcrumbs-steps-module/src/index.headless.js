import registerTopic from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.topicRegistration';

registerTopic();
