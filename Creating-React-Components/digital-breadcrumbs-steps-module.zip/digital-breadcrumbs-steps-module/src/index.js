import SDK from 'digital-sdk';

import Widget from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps';
import connect from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.connect';
import registerTopic from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.topicRegistration';
import descriptor from '../digital-breadcrumbs-steps-module.descriptor.json';

registerTopic();

const ConnectedWidget = connect(Widget);

const widgetObj = {
    Widget,
    ConnectedWidget,
    descriptor,
    id: descriptor.widgetId
};


export {
    widgetObj as default
};

SDK.exportGlobal(`amdocs.widgets.${widgetObj.id}`, widgetObj);
