import SDK from 'digital-sdk';

import ActionTypes from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actionTypes';
import SDKConfig from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.sdk.config';
import {SUCCESS_SUFFIX} from 'digital-sdk/lib/actions/types/const';

const initialState = {};

const reducer = (state = initialState, action) => {
    const {type, payload = {}} = action;
    let newState;
    switch (type) {
    case ActionTypes.SET_BREADCRUMBS_STEPS_INPUT_PARAMETERS:
    case ActionTypes.UPDATE_STATE:
        newState = {
            ...state,
            ...payload
        };
        break;
    case ActionTypes.CLEAN_ORDER_LEVEL:
        newState = {
            ...initialState,
            viewDataParams: state.viewDataParams
        };
        break;
    default:
        newState = state;
        break;
    }
    return newState;
};

const registrationFunc = () => {
    const {level, name} = SDKConfig;
    SDK.registerLevelReducer(level, name, reducer);
};

export {
    reducer as default,
    registrationFunc as registerReducer
};
