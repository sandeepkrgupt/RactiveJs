import SDK from 'digital-sdk';

const config = {
    name: 'breadcrumbs-steps',
    level: SDK.ActionsLevels.ORDER_LEVEL
};

export default config;
