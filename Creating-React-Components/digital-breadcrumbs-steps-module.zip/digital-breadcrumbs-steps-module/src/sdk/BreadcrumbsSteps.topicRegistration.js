import SDK from 'digital-sdk';
import Actions from
'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actions';
import mapStateToProps from
'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.stateMapping';
import SDKConfig from
'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.sdk.config';


export default function() {
    SDK.registerToHub({
        Actions,
        mapModelStateToProps: mapStateToProps,
        actionType: SDKConfig
    });
}
