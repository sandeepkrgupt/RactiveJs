import SDK from 'digital-sdk';

import actionsConfig from
    'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actions.config';
import errorConfig from
    'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.errors';
import SDKConfig from
    'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.sdk.config';
import ActionTypes from
    'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actionTypes';
import {registerReducer} from 'digital-breadcrumbs-steps-module/src/sdk/reducers/BreadcrumbsSteps.reducer';

registerReducer();

export default class extends SDK.ActionClass {
    constructor(connectParams, store) {
        super(connectParams, store, SDKConfig, actionsConfig, errorConfig);
    }

    setInputParameters(data) {
        if (data && data.breadcrumbsParent && data.currentStep) {
            const {subHeadings} = this.getData();
            const callFrom = data.breadcrumbsParent;
            const currentStep = data.currentStep;

            this.dispatchStoreAction(ActionTypes.SET_BREADCRUMBS_STEPS_INPUT_PARAMETERS, {
                callFrom,
                currentStep,
                subHeadings: {
                    ...subHeadings
                }
            });
        }
    }

    setActions() {
        super.setActions();
    }

    updateCurrentStep(stepNumber) {
        this.dispatchStoreAction(ActionTypes.UPDATE_STATE, {
            currentStepIndex: stepNumber
        });
    }

    getPublicActions() {
        return [
            'updateCurrentStep'
        ];
    }
}

