import messages from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.i18n';

/*
------------------------------- SALES AGREEMENT WIZARD ------------------------------------
*/
const AGREEMENT = messages.salesAgreement.agreement;
const DELIVERY = messages.salesAgreement.delivery;
const BUSINESS_GROUP = messages.salesAgreement.businessGroup;
const PLANS_AND_DEVICES = messages.salesAgreement.planAndDevices;
const SUMMARY = messages.salesAgreement.summary;

export {
    AGREEMENT,
    DELIVERY,
    BUSINESS_GROUP,
    PLANS_AND_DEVICES,
    SUMMARY
};
