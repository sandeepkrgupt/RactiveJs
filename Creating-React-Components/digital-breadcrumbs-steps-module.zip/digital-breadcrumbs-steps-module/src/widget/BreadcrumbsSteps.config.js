import {
    AGREEMENT,
    DELIVERY,
    BUSINESS_GROUP,
    PLANS_AND_DEVICES,
    SUMMARY
} from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.consts';

const salesAgreementWizard = {
    steps: [
        AGREEMENT,
        DELIVERY,
        BUSINESS_GROUP,
        PLANS_AND_DEVICES,
        SUMMARY
    ]
};

export default{
    salesAgreementWizard
};
