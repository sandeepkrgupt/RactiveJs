import React, {Component} from 'react';
import PropTypes from 'prop-types';

import BreadcrumbsStepsMainView from 'digital-breadcrumbs-steps-module/src/widget/templates/BreadcrumbsSteps.mainView';
import BreadcrumbsStepsProps from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.propsProvider';

class BreadcrumbsStepsComponent extends Component {
    static get contextTypes() {
        return {
            policy: PropTypes.func,
            permissions: PropTypes.object,
            config: PropTypes.object
        };
    }

    constructor(props) {
        super(props);
        this.propsProvider = new BreadcrumbsStepsProps(this.context);
    }

    render() {
        return <BreadcrumbsStepsMainView {...this.propsProvider.getComponentProps(this.props)} />;
    }
}

export default BreadcrumbsStepsComponent;
