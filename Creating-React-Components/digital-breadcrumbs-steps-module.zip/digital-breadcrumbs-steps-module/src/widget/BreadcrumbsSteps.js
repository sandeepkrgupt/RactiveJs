import Component from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.component';
import Decorator from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.decorator';

export default Decorator(Component);
