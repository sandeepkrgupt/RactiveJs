import React from 'react';
import wizardSteps from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.config';
import {Popover} from 'react-bootstrap';

export default function BreadcrumbsStepsMainView(viewProps) {
    /*
    ------------------------------- HANDLERS ------------------------------------
    */

    /*
    ------------------------------- SUB COMPONENT -------------------------------
    */
    const
    const steps = wizardSteps[viewProps.callFrom].steps.map((name, index) => {

        const stepNumberDisplay = index + 1;

        let activeBreadCrumbClass = '';
        let doneBreadcrumbClass = 'done';
        if (name.id === viewProps.currentStep) {
            activeBreadCrumbClass = 'active';
            viewProps.updateCurrentStep(stepNumberDisplay);
        }

        if (stepNumberDisplay >= viewProps.currentStepIndex) {
            doneBreadcrumbClass = '';
        }

        return (
            <div
                className={`steps-item ${activeBreadCrumbClass} ${doneBreadcrumbClass}`}
                key={name.id}
            >
                {name.defaultMessage}
            </div>
        );
    });

    /*
    ------------------------------- FINAL COMPONENT -----------------------------
    */
    return (
        <div className="steps">
            <div className="container steps-wrap">
                {steps}
            </div>
        </div>
    );
}
