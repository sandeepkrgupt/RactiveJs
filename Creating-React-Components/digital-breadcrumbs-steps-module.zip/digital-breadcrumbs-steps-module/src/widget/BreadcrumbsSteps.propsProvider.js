class PropsProvider {
    constructor(context) {
        this.context = context;
    }

    getComponentProps(props) {
        const {actions} = props;
        const {updateCurrentStep} = actions;
        return {
            callFrom: props.callFrom,
            subHeadings: props.subHeadings,
            currentStep: props.currentStep,
            updateCurrentStep,
            currentStepIndex: props.currentStepIndex
        };
    }
}

export default PropsProvider;
