import SDK from 'digital-sdk';
import Actions from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actions';
import SDKConfig from '../sdk/BreadcrumbsSteps.sdk.config';

const {viewDataConnect} = SDK.DigitalConnect;
const {level, name} = SDKConfig;
const connect = viewDataConnect.connectWidget(level, name, Actions);

export {
    connect as default
};
