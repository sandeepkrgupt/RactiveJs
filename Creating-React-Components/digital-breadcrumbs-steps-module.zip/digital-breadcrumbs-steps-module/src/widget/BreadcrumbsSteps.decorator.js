import SDK from 'digital-sdk';
import Actions from 'digital-breadcrumbs-steps-module/src/sdk/BreadcrumbsSteps.actions';
import defaultConfig from 'digital-breadcrumbs-steps-module/src/widget/BreadcrumbsSteps.config';

const {ConnectedContainer} = SDK.DigitalComponents;
const ContainerDecorator = ConnectedContainer({
    config: {
        actionsClass: Actions,
        ...defaultConfig
    },
    propTypes: {
    }
});

export default ContainerDecorator;
