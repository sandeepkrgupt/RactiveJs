import {defineMessages} from 'react-intl';

export default defineMessages({
    breadcrumbSubHeading: {
        id: 'breadcrumbSubHeading',
        defaultMessage: 'Hi I am subheading, trying to occupy more space than my width. Let see if I get wrapped'
    },
    salesAgreement: {
        agreement: {
            id: 'salesAgreement.breadcrumb.agreement',
            defaultMessage: 'Acuerdo'
        },
        delivery: {
            id: 'salesAgreement.breadcrumb.delivery',
            defaultMessage: 'Entrega'
        },
        businessGroup: {
            id: 'salesAgreement.breadcrumb.businessGroup',
            defaultMessage: 'Grupo de Negocio'
        },
        planAndDevices: {
            id: 'salesAgreement.breadcrumb.planAndDevices',
            defaultMessage: 'Planes y Dispositivos'
        },
        summary: {
            id: 'salesAgreement.breadcrumb.summary',
            defaultMessage: 'Resumen'
        }
    }
});
