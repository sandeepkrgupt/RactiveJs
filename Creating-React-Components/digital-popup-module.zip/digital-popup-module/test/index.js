// require all specs
const testsContext = require.context('.', true, /specs\.js$/);
testsContext.keys().forEach(testsContext);
