const actionsConfig = {
    inlineLoader: true,
    inlineMessage: true
};

export default actionsConfig;
