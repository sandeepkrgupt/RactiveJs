import SDK from 'digital-sdk';
import Actions from
'digital-popup-module/src/sdk/Popup.actions';
import mapStateToProps from
'digital-popup-module/src/sdk/Popup.stateMapping';
import SDKConfig from
'digital-popup-module/src/sdk/Popup.sdk.config';

export default function() {
    SDK.registerToHub({
        Actions,
        mapModelStateToProps: mapStateToProps,
        actionType: SDKConfig
    });
}
