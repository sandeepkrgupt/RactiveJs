
import SDK from 'digital-sdk';

import ActionTypes from 'digital-popup-module/src/sdk/Popup.actionTypes';
import SDKConfig from 'digital-popup-module/src/sdk/Popup.sdk.config';

const initialState = {
    showPopup: false,
    header: ''
};

const reducer = (state = initialState, action) => {
    const {type, payload = {}} = action;
    let newState;
    switch (type) {
    case ActionTypes.SET_POPUP_INIT:
        newState = Object.assign({}, state, {showPopup: payload});
        break;
    case ActionTypes.GO_TO_LOGIN_SCREEN:
    case ActionTypes.GO_TO_SEARCH_CUSTOMER:
        newState = {
            ...state,
            ...payload
        };
        break;
    case ActionTypes.OPEN_POPUP:
        newState = Object.assign({}, state, {
            showPopup: true,
            header: payload.header,
            body: payload.body,
            footer: payload.footer,
            backdrop: payload.backdrop != null ? payload.backdrop : true,
            closeButton: payload.closeButton != null ? payload.closeButton : true,
            closeButtonAction: payload.closeButtonAction,
            popupType: payload.popupType,
            popupPaymentData: payload.popupPaymentData
        });
        break;
    case ActionTypes.CLOSE_POPUP:
        newState = Object.assign({}, state, {
            showPopup: false,
            header: '',
            body: '',
            footer: '',
            backdrop: true,
            closeButton: true,
            popupPaymentData: null
        });
        break;
    case ActionTypes.CLEAN_APPLICATION_LEVEL:
        newState = {
            ...initialState,
            viewDataParams: state.viewDataParams
        };
        break;
    default:
        newState = Object.assign({}, state);
        break;
    }
    return newState;
};

const registrationFunc = () => {
    const {level, name} = SDKConfig;
    SDK.registerLevelReducer(level, name, reducer);
};

export {
    reducer as default,
    registrationFunc as registerReducer
};
