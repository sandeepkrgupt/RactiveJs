import {pick as _pick} from 'lodash';
import React, {Component} from 'react';
import SDK from 'digital-sdk';
import actionsConfig from 'digital-popup-module/src/sdk/Popup.actions.config';
import errorConfig from 'digital-popup-module/src/sdk/Popup.errors';
import SDKConfig from 'digital-popup-module/src/sdk/Popup.sdk.config';
import ActionTypes from 'digital-popup-module/src/sdk/Popup.actionTypes';
import {registerReducer} from 'digital-popup-module/src/sdk/reducers/Popup.reducer';

registerReducer();

export default class extends SDK.ActionClass {
    constructor(connectParams, store) {
        super(connectParams, store, SDKConfig, actionsConfig, errorConfig);
    }

    setInputParameters() {
        this.dispatchStoreAction(ActionTypes.SET_POPUP_INIT, false);
    }

    setActions() {
        super.setActions();
    }

    openPopup(data) {
        const {header, body, footer, backdrop, closeButton, closeButtonAction, popupType, popupPaymentData} = data;
        this.dispatchStoreAction(ActionTypes.OPEN_POPUP,
            {header, body, footer, backdrop, closeButton, closeButtonAction, popupType, popupPaymentData});
    }

    closePopup() {
        this.dispatchStoreAction(ActionTypes.CLOSE_POPUP, {});
    }

    getPublicActions() {
        return [
            'openPopup',
            'closePopup'
        ];
    }

    onStateUpdate(/* data */) {
        // here is the place to respond to relevant state data changes and call relevant actions
        // data argument contains the module mapped state data
    }
}

