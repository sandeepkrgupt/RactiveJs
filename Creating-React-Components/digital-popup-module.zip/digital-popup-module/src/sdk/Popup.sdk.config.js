import SDK from 'digital-sdk';

const config = {
    name: 'popup',
    level: SDK.ActionsLevels.APPLICATION_LEVEL
};

export default config;
