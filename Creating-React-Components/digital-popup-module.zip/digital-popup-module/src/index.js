import SDK from 'digital-sdk';

import Widget from 'digital-popup-module/src/widget/Popup';
import connect from 'digital-popup-module/src/widget/Popup.connect';
import registerTopic from 'digital-popup-module/src/sdk/Popup.topicRegistration';
import descriptor from '../digital-popup-module.descriptor.json';

registerTopic();

const ConnectedWidget = connect(Widget);

const widgetObj = {
    Widget,
    ConnectedWidget,
    descriptor,
    id: descriptor.widgetId
};


export {
    widgetObj as default
};

SDK.exportGlobal(`amdocs.widgets.${widgetObj.id}`, widgetObj);
