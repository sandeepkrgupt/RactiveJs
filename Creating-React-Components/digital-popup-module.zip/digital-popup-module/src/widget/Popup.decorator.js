import SDK from 'digital-sdk';
import Actions from 'digital-popup-module/src/sdk/Popup.actions';
import defaultConfig from 'digital-popup-module/src/widget/Popup.config';

const {ConnectedContainer} = SDK.DigitalComponents;
const ContainerDecorator = ConnectedContainer({
    config: {
        actionsClass: Actions,
        ...defaultConfig
    },
    propTypes: {
    }
});

export default ContainerDecorator;
