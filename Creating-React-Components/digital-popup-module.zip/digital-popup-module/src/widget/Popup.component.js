import React, {Component} from 'react';
import PropTypes from 'prop-types';

import PopupMainView from 'digital-popup-module/src/widget/templates/Popup.mainView';
import PopupProps from 'digital-popup-module/src/widget/Popup.propsProvider';

class PopupComponent extends Component {
    static get contextTypes() {
        return {
            policy: PropTypes.func,
            permissions: PropTypes.object,
            config: PropTypes.object
        };
    }

    constructor(props) {
        super(props);
        this.propsProvider = new PopupProps(this.context);
    }

    render() {
        return <PopupMainView {...this.propsProvider.getComponentProps(this.props)} />;
    }
}

export default PopupComponent;

