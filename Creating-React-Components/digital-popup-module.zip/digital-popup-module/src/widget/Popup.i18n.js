import {defineMessages} from 'react-intl';

export default defineMessages({
    test: {
        id: 'test',
        defaultMessage: 'This is a test View for: {name}'
    },
    nameInputPlaceholder: {
        id: 'nameInputPlaceholder',
        defaultMessage: 'Enter your name here'
    },
    result: {
        id: 'result',
        defaultMessage: 'Result:&nbsp;'
    },
    selectUpToText: {
        id: 'selectUpToText',
        defaultMessage: 'Seleccione hasta'
    },
    monthsText: {
        id: 'monthsText',
        defaultMessage: 'meses'
    },
    saveAndCloseButtonText: {
        id: 'saveAndCloseButtonText',
        defaultMessage: 'Guardar y Cerrar'
    },
    clearAllLinkText: {
        id: 'clearAllLinkText',
        defaultMessage: 'Limpiar Todo'
    },
    cancelButtonText: {
        id: 'cancelButtonText',
        defaultMessage: 'Cancelar'
    }
});
