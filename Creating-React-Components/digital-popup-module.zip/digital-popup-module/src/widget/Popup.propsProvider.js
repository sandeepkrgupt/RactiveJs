class PropsProvider {
    constructor(context) {
        this.context = context;
    }
    getComponentProps(props) {
        const {actions} = props;
        return {
            header: props.header,
            body: props.body,
            footer: props.footer,
            backdrop: props.backdrop,
            closeButton: props.closeButton,
            closeButtonAction: props.closeButtonAction,
            showPopup: props.showPopup,
            popupType: props.popupType,
            popupPaymentData: props.popupPaymentData,
            openPopup: actions.openPopup,
            closePopup: actions.closePopup
        };
    }
}

export default PropsProvider;
