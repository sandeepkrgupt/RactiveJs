import Component from 'digital-popup-module/src/widget/Popup.component';
import Decorator from 'digital-popup-module/src/widget/Popup.decorator';

export default Decorator(Component);
