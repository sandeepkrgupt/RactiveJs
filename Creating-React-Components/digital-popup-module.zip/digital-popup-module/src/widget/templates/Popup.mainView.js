import React from 'react';
import {Modal} from 'react-bootstrap';
import DigitalComponents from 'digital-common-components';
import PaymentBox from './Popup.paymentBox';
import Generic from './Popup.generic';
import FreeMonths from './Popup.freeMonths';

export default class Popup extends React.Component {

    render() {
        let modalType;
        if (this.props.popupType === 'payment') {
            modalType = (<PaymentBox {...this.props} />);
        } else if (this.props.popupType === 'freeMonths') {
            modalType = (<FreeMonths {...this.props} />);
        } else {
            modalType = (<Generic {...this.props} />);
        }

        return (
            <div>
                {this.props.showPopup && modalType}
            </div>
        );
    }
}
