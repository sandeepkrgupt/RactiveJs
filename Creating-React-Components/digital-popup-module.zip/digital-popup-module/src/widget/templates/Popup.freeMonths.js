/* eslint-disable no-plusplus */
import React from 'react';
import {Modal} from 'react-bootstrap';
import messages from 'digital-popup-module/src/widget/Popup.i18n';
import DigitalComponents from 'digital-common-components';


export default class Popup extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            startFromMonth: 0,
            preSelectedMonths: [],
            selectedMonths: [],
            totalSelectedMonths: 0,
            disabledMonths: [],
            totalMonthsNumber: 0,
            totalMonthsArray: [],
            interval: 0,
            freeMonthSelected: false,
            clearAll: false,
            maxFreeMonths: 0
        };
        this.handleClearAll = this.handleClearAll.bind(this);
        this.showAllMonths = this.showAllMonths.bind(this);
        this.performUpdateFreeMonths = this.performUpdateFreeMonths.bind(this);
        this.handleSelectFreeMonth = this.handleSelectFreeMonth.bind(this);
        this.updateFreeMonths = this.props.footer.rightButton.action;
    }

    componentDidMount() {
        this.initiateMonths();
    }

    componentWillUnmount() {

    }

    initiateMonths() {
        const data = this.props.body;
        const {startFromMonth, preSelectedMonths, interval, totalMonthsNumber, maxFreeMonths} = JSON.parse(data);
        const disabledMonths = [];
        const totalMonths = Array.from(new Array(totalMonthsNumber), (x, i) => ({
            id: i + 1,
            selected: false,
            disabled: i + 1 < startFromMonth
        }));
        preSelectedMonths.forEach((value) => {
            const startIndex = value - interval;
            const endIndex = value + interval;
            for (let i = startIndex + 1; i < endIndex; i++) {
                disabledMonths[i] = i;
            }
        });
        const prepareSelectedMonths = totalMonths.map((month) => {
            if (preSelectedMonths.includes(month.id)) {
                month.selected = true;
                month.disabled = true;
            }
            if (disabledMonths.includes(month.id) || preSelectedMonths.length >= maxFreeMonths) {
                month.disabled = true;
            }
            return month;
        });
        this.setState({
            totalMonthsArray: prepareSelectedMonths,
            disabledMonths,
            interval,
            totalMonthsNumber,
            totalSelectedMonths: preSelectedMonths.length,
            startFromMonth,
            preSelectedMonths,
            maxFreeMonths
        });
    }

    handleSelectFreeMonth(id) {
        const self = this;
        return function (event) {
            event.preventDefault();
            const disabledMonths = self.state.disabledMonths;
            const selectedMonths = id;
            const startIndex = selectedMonths - self.state.interval;
            const endIndex = selectedMonths + self.state.interval;
            for (let i = startIndex + 1; i < endIndex; i++) {
                disabledMonths[i] = i;
            }
            const prepareSelectedMonths = self.state.totalMonthsArray.map((month) => {
                if (selectedMonths === month.id) {
                    month.selected = true;
                    month.disabled = true;
                }
                if (disabledMonths.includes(month.id) || self.state.totalSelectedMonths + 1 === self.state.maxFreeMonths) {
                    month.disabled = true;
                }
                return month;
            });
            self.setState({
                totalMonthsArray: prepareSelectedMonths,
                disabledMonths,
                selectedMonths: [...self.state.selectedMonths, selectedMonths],
                freeMonthSelected: true,
                totalSelectedMonths: self.state.totalSelectedMonths + 1
            });
        };
    }

    handleClearAll(event) {
        event.preventDefault();
        const disabledMonths = [];
        const prepareSelectedMonths = this.state.totalMonthsArray.map((month) => {
            if (month.id < this.state.startFromMonth) {
                month.disabled = true;
                disabledMonths.push(month.id);
            } else {
                month.disabled = false;
                month.selected = false;
            }
            return month;
        });

        this.setState({
            totalMonthsArray: prepareSelectedMonths,
            disabledMonths,
            selectedMonths: [],
            freeMonthSelected: false,
            totalSelectedMonths: 0,
            clearAll: true
        });
    }

    showAllMonths() {
        return (
            <div className="month-grid">
                {this.state.totalMonthsArray.map(month => (
                    <div
                        className={`month-grid-item ${month.selected ? 'active' : ''} ${
                            month.disabled ? 'disable' : ''
                            }`}
                        onClick={this.handleSelectFreeMonth(month.id)}
                        key={month.id.toString()}
                    >
                        {month.id}
                    </div>
                ))}
            </div>
        );
    }

    performUpdateFreeMonths() {
        const months = this.state.clearAll
            ? [...this.state.selectedMonths].sort((a, b) => a - b)
            : [...this.state.preSelectedMonths, ...this.state.selectedMonths].sort((a, b) => a - b);
        this.updateFreeMonths(months, true);
    }
    render() {
        const ModalHeader = Modal.Header;
        const ModalBody = Modal.Body;
        const ModalFooter = Modal.Footer;
        return (
            <Modal show={this.props.showPopup} onHide={this.props.closePopup} backdrop={this.props.backdrop}>
                <ModalHeader closeButton>
                    <h2 className="modal-title">
                        {this.props.header.img &&
                        <img className="modal-title-icon" src={this.props.header.img} alt="" />}
                        {this.props.header.title}
                    </h2>
                </ModalHeader>
                <ModalBody>
                    <div className="justify text-gray">
                        {`${messages.selectUpToText.defaultMessage} ${this.state.maxFreeMonths} ${messages.monthsText.defaultMessage}`}
                        <a onClick={this.handleClearAll}>
                            {messages.clearAllLinkText.defaultMessage}
                        </a>
                    </div>
                    {this.showAllMonths()}
                </ModalBody>
                <ModalFooter>
                    <button
                        type="button"
                        className="btn btn-primary"
                        data-dismiss="modal"
                        onClick={this.props.closePopup}
                    >
                        {messages.cancelButtonText.defaultMessage}
                    </button>
                    <button
                        type="button"
                        data-dismiss="modal"
                        className={`btn ${
                            this.state.freeMonthSelected
                                ? 'btn-primary'
                                : 'btn-gray disabled'
                            }`}
                        onClick={this.performUpdateFreeMonths}
                        disabled={!this.state.freeMonthSelected}
                    >
                        {messages.saveAndCloseButtonText.defaultMessage}
                    </button>
                </ModalFooter>
            </Modal>
        );
    }
}
