import React from 'react';
import {Modal} from 'react-bootstrap';

export default class Popup extends React.Component {
    constructor() {
        super();
        this.state = {isHandledMessage: false};
    }

    componentDidMount() {
        window.addEventListener('message', e => this.handleMessage(e), false);

        const paymentForm = document.getElementById('paymentFormId');
        paymentForm.submit();
    }

    handleMessage(e) {
        if ((this.props.popupPaymentData && this.props.popupPaymentData.targetURL &&
            !this.props.popupPaymentData.targetURL.includes(e.origin)) || this.state.isHandledMessage) {
            return;
        }
        this.handleResponse(e.data);
    }

    handleResponse(data) {
        if (data) {
            const responseData = JSON.parse(data);
            if (responseData && responseData.message) {
                window.removeEventListener('message', e => this.handleMessage(e), false);
                this.props.closePopup();
                if (this.props.popupPaymentData && this.props.popupPaymentData.updatePBPaymentConfirmation) {
                    this.props.popupPaymentData.updatePBPaymentConfirmation(responseData);
                }
                this.setState({isHandledMessage: true});
            }
        }
    }

    render() {
        const ModalHeader = Modal.Header;
        return (
            <Modal show={this.props.showPopup} onHide={this.props.closePopup} dialogClassName="paymentBoxModal">
                <ModalHeader closeButton />
                <form
                    action={this.props.popupPaymentData.targetURL}
                    method="post"
                    target="PaymentIframeName"
                    id="paymentFormId">
                    <input type="hidden" name="createPayOrder" value={JSON.stringify(this.props.body)} />
                </form>
                <iframe className="iframPaymentBox" title="paymentIframeTitle" src="" name="PaymentIframeName" />
            </Modal>
        );
    }
}
