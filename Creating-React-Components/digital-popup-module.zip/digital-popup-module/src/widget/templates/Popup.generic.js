import React from 'react';
import {Modal} from 'react-bootstrap';
import DigitalComponents from 'digital-common-components';

export default class Popup extends React.Component {

    render() {
        const ModalHeader = Modal.Header;
        const ModalBody = Modal.Body;
        const ModalFooter = Modal.Footer;

        return (
            <Modal show={this.props.showPopup} onHide={this.props.closePopup} backdrop={this.props.backdrop}>
                <ModalHeader closeButton={this.props.closeButton} onHide={this.props.closeButtonAction}>
                    <h2 className="modal-title">
                        {this.props.header.img &&
                        <img className="modal-title-icon" src={this.props.header.img} alt="" />}
                        {this.props.header.title}
                    </h2>
                </ModalHeader>
                <ModalBody>
                    {this.props.body}
                </ModalBody>
                <ModalFooter>
                    {this.props.footer.leftButton &&
                    <button
                        disabled={this.props.footer.leftButton.disabled}
                        type="button"
                        onClick={() => this.props.footer.leftButton.action()}
                        className="btn btn-secondary"
                        data-dismiss="modal">{this.props.footer.leftButton.title}</button>
                    }
                    {this.props.footer.rightButton &&
                        <button
                            disabled={this.props.footer.rightButton.disabled}
                            type="button"
                            onClick={() => this.props.footer.rightButton.action()}
                            className="btn btn-primary"
                            data-dismiss="modal">{this.props.footer.rightButton.title}</button>
                    }
                </ModalFooter>
            </Modal>
        );
    }
}
