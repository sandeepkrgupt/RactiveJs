export default {
    defaultName: 'Popup'
};
