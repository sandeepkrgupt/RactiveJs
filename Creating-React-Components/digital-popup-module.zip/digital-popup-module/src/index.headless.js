import registerTopic from 'digital-popup-module/src/sdk/Popup.topicRegistration';

registerTopic();
