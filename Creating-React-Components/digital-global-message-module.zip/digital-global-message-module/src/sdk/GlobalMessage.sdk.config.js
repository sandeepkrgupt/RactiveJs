import SDK from 'digital-sdk';

const config = {
    name: 'global-message',
    level: SDK.ActionsLevels.APPLICATION_LEVEL
};

export default config;
