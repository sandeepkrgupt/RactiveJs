export default {
    serverMapping: [

    ],
    mapping: [

    ]
};
