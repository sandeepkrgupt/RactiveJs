import registerTopic from 'digital-global-message-module/src/sdk/GlobalMessage.topicRegistration';

registerTopic();
