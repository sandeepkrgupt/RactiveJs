import Component from 'digital-global-message-module/src/widget/GlobalMessage.component';
import Decorator from 'digital-global-message-module/src/widget/GlobalMessage.decorator';

export default Decorator(Component);
