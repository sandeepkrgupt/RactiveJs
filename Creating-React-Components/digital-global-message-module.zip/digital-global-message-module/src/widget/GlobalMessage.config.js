export default {
    defaultName: 'GlobalMessage'
};
