import React from 'react';
import {FormattedHTMLMessage} from 'react-intl';
import {Modal} from 'react-bootstrap';
import messagesDescription from 'digital-global-message-module/src/widget/GlobalMessage.i18n';

let currentView;

const Success = (viewConfig) => {
    let messageDetails = '';
    if (viewConfig.messageDetails) {
        messageDetails = viewConfig.messageDetails;
        if (messageDetails.messageCode && !messageDetails.messageData) {
            messageDetails.messageData = messagesDescription[messageDetails.messageCode];
        }
        messageDetails.messageParams = messageDetails.messageParams || {};
    }
    return (
        <div className="container-fluid">
            <div className="row">
                <div className="alert alert-success alert-close">
                    <div className="alert-close-icon alert-close-bg">
                        <img src="resources/pic/check_bold.svg" alt="" />
                    </div>
                    {messageDetails.messageData.defaultMessage}
                    <button type="button" className="close" onClick={viewConfig.clearMessage} aria-hidden="true">
                        <img src="resources/img/close.svg" alt="close" />
                    </button>
                </div>
            </div>
        </div>
    );
};


const Loader = () => {
    return (
        <div className="att-loader-container">
            <div className="cssload-loader att-custom-loader">
                <div className="cssload-loader-inner" />
            </div>
        </div>
    );
};

const attentionMessage = (messageDetails, clearMessage) => {
    return (
        <div className="att-alert-warning d-block">
            <div className="att-alert-text">
                <FormattedHTMLMessage {...messageDetails.messageData} />
            </div>
            <span className="glyphicon glyphicon-remove fs-21 pd-lr-10 fl-right" onClick={clearMessage} />
        </div>
    );
};

const isIgnoreError = (serviceType) => {
    const serviceTypesToCustomize = ['CANCEL_ORDER'];
    return serviceTypesToCustomize.includes(serviceType);
};

const ErrorView = (viewConfig) => {
    let displayErrorUUID = sessionStorage.getItem('displayErrorUUID');
    displayErrorUUID = (displayErrorUUID === 'true');
    let messageDetails = '';
    if (isIgnoreError(viewConfig.serviceType)) {
        return (<div />);
    }
    if (viewConfig.messageDetails) {
        messageDetails = viewConfig.messageDetails;
        if (messageDetails.messageCode && !messageDetails.messageData) {
            messageDetails.messageData = messagesDescription[messageDetails.messageCode];
        }
    }
    return (
        <div className="alert alert-danger alert-close">
            <div className="alert-close-icon alert-close-bg">
                <img src="resources/img/alert_circle_white.svg" alt="" />
            </div>
            {displayErrorUUID &&
            (<div>
                <strong>Error UUID: {viewConfig.errorUUID}&nbsp;</strong><span>{messageDetails.messageData.defaultMessage}</span>
            </div>)}
            {!displayErrorUUID &&
            (<div>
                {messageDetails.messageData.defaultMessage}
            </div>)}
            <button
                type="button"
                className="close"
                onClick={viewConfig.clearMessage}
                aria-hidden="true">
                <img src="resources/img/close.svg" alt="close" />
            </button>
        </div>
    );
};

const Info = (viewConfig) => {
    let messageDetails = '';
    if (viewConfig.messageDetails) {
        messageDetails = viewConfig.messageDetails;
        if (messageDetails.messageCode && !messageDetails.messageData) {
            messageDetails.messageData = messagesDescription[messageDetails.messageCode];
        }
    }
    const message = attentionMessage(messageDetails, viewConfig.clearMessage, 'attention-red');
    return message;
};

const Warning = (viewConfig) => {
    let messageDetails = '';
    if (viewConfig.messageDetails) {
        messageDetails = viewConfig.messageDetails;
        if (messageDetails.messageCode && !messageDetails.messageData) {
            messageDetails.messageData = messagesDescription[messageDetails.messageCode];
        }
    }
    // 3rd Param : class Param
    const message = attentionMessage(messageDetails, viewConfig.clearMessage, 'attention-orange');
    return message;
};

const Fatal = (viewConfig) => {
    return Error(viewConfig);
};


function GlobalMessageSubComponent (props) {
    currentView = props.topicName;

    return (
        <div hidden />
    );
}
export {
    Success,
    Loader,
    ErrorView,
    Info,
    Warning,
    Fatal,
    GlobalMessageSubComponent
};
