/* eslint no-unused-expressions: 0  prefer-arrow-callback: 0 */
import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

export function tests() {

}

export default tests();
