const jsdomGlobal = require('jsdom-global');
require('mock-local-storage');

jsdomGlobal();

window.localStorage = global.localStorage;
window.sessionStorage = global.sessionStorage;
