export default {
    activeFnfSelection: 'selection-buttons-comp container',
    colMediumFour: 'col-md-4',
    materialIconRight: 'material-icons icon-right',
    headingContainer: 'heading-container row',
    columnFour: 'col-4',
    fullWidthCenter: 'col-12 text-center',
    tickmark: '/etc/clientlibs/digitalexp/js/style/css/images/green-right-tick-mark.png'
};
