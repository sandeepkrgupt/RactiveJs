import registerTopic from 'digital-login-module/src/sdk/Login.topicRegistration';

registerTopic();
