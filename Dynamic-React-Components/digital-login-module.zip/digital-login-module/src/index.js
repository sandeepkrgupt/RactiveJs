import SDK from 'digital-sdk';

import Widget from 'digital-login-module/src/widget/Login';
import connect from 'digital-login-module/src/widget/Login.connect';
import registerTopic from 'digital-login-module/src/sdk/Login.topicRegistration';
import descriptor from '../digital-login-module.descriptor.json';

registerTopic();

const ConnectedWidget = connect(Widget);

const widgetObj = {
    Widget,
    ConnectedWidget,
    descriptor,
    id: descriptor.widgetId
};


export {
    widgetObj as default
};

SDK.exportGlobal(`amdocs.widgets.${widgetObj.id}`, widgetObj);
