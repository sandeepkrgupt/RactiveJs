export default {
    defaultName: 'Login',
    user: {
        mandatory: true,
        maxLength: 20
    },
    password: {
        mandatory: true,
        maxLength: 20
    },
    customerId: {
        mandatory: true,
        maxLength: 20
    }
};
