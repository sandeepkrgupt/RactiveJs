import Component from 'digital-login-module/src/widget/Login.component';
import Decorator from 'digital-login-module/src/widget/Login.decorator';

export default Decorator(Component);
