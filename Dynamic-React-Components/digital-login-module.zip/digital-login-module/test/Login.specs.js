import React from 'react';

import {expect} from 'chai';
import {shallow} from 'enzyme';

export function tests() {
}

export default tests();
